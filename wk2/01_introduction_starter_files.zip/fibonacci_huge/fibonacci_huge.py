# Uses python3
import sys

def get_fibonaccihuge(n, m):
    # write your code here
    return 0

if __name__ == '__main__':
    input = sys.stdin.read();
    n, m = map(int, input.split())
    print(get_fibonaccihuge(n, m))
